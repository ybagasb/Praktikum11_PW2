<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen extends CI_Controller {
    public function index(){
        $this->load->model('Mahasiswa_model','mahasiswa');
        $list_mhs = $this->mahasiswa->getAll();
    }

    public function create(){
 
    }

    public function save(){
 
    }
}